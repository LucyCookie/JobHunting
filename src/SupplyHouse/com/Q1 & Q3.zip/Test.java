package SupplyHouse.com;

import SupplyHouse.com.ProductSupply.FileProcessor;
import SupplyHouse.com.ProductSupply.FileProcessorFactory;

import java.io.File;
import java.sql.PreparedStatement;

/**
 * Created by qiqu on 2/1/16.
 */
public class Test {
    public static void main(String[] args) {
        new Swoosh().drawSwoosh(30);

        //Question 3
        //example usage of transferring the supplier files into DB
        {
            try {
                String fileName = "test.csv";
                File file = new File("." + fileName);
                String name = fileName.split("\\.")[0], extension = fileName.split("\\.")[1];
                PreparedStatement pst = null;
                FileProcessor processor = FileProcessorFactory.getProcessor(name, extension, pst, file);
                processor.transferToDB();
            } catch (Exception e) {}
        }
    }
}
